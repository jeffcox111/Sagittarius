This zip file contains the mesh and all texture maps necessary barring 
commercially available procedural maps which are not freeware.

Unzip the file copying the image files into a directory in your map
path.

This mesh is freely available for use in all non-commercial purposes.

For the latest copies of all meshes be sure to visit my btech/wh40k
3d resource at http://www.ice.org/~megalith

G.W.Chapman (megalith@ice.org)

Note, I am in no way, affiliated or recognized by Citadel Miniatures/
Games Workshop or the FASA corporation.

All copyrights and trademarks are property of their respective owners